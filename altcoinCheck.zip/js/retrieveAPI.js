﻿
var addr = "https://api.coinmarketcap.com/v1/ticker/";
var request = new XMLHttpRequest();
var tag = "bitcoin"

request.onreadystatechange = function () {
     if (this.readyState == 4 && this.status == 200) {
          var response = JSON.parse(this.responseText);
          document.getElementById("btc").innerHTML = "$" + response[0].price_usd;
          document.getElementById("eth").innerHTML = "$" + response[1].price_usd;
          document.getElementById("bch").innerHTML = "$" + response[2].price_usd;
          document.getElementById("xrp").innerHTML = "$" + response[3].price_usd;
          document.getElementById("ltc").innerHTML = "$" + response[4].price_usd;
          document.getElementById("dash").innerHTML = "$" + response[6].price_usd;
          document.getElementById("xmr").innerHTML = "$" +  response[7].price_usd;
          document.getElementById("etc").innerHTML = "$" + response[8].price_usd;
          document.getElementById("xlm").innerHTML = "$" + response[20].price_usd;
     };
};
request.open("GET", addr, true);
request.send();
